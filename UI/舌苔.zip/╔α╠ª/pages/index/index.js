Page({
  data: {
    
  },
  
  enterSystem() {
    wx.navigateTo({
      url: '../upload/upload'
    })
  }
}) 