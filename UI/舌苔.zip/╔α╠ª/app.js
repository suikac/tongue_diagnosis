App({
  onLaunch() {
    
  },
  globalData: {
    
  }
}) 